import React from 'react';
import { Wallet } from 'lucide-react';
import { Page, User } from '../types';
import SafeImage from './SafeImage';
import { useAppBranding } from '../hooks/useAppBranding';

interface HeaderProps {
  user: User;
  onPageChange: (page: Page) => void;
}

export default function Header({ user, onPageChange }: HeaderProps) {
  const totalBalance =
    (user.wallet?.deposit || 0) + (user.wallet?.winnings || 0) + (user.wallet?.bonus || 0);
  const { appName, appLogoUrl, renderSplitAppName } = useAppBranding();

  return (
    <header className="sticky top-0 z-40 bg-[#050505]/80 backdrop-blur-md py-3.5 transition-colors">
      <div className="flex items-center justify-between px-5 max-w-lg mx-auto">
        <div className="flex items-center gap-3">
          <div
            onClick={() => onPageChange(Page.PROFILE)}
            className="w-11 h-11 rounded-2xl overflow-hidden cursor-pointer bg-transparent shrink-0 shadow-[0_0_18px_rgba(243,122,32,0.45)]"
          >
            <SafeImage
              src={appLogoUrl}
              alt={appName}
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <div className="flex items-center gap-1.5 mb-0.5">
              <span className="text-[9px] text-[#7a7a7a] font-bold uppercase tracking-[0.2em] leading-none">
                Server Online
              </span>
              <div className="w-1.5 h-1.5 rounded-full bg-[#22C55E] shadow-[0_0_8px_rgba(34,197,94,0.5)]" />
            </div>
            <h1 className="text-lg sm:text-[22px] font-extrabold tracking-[0.05em] uppercase leading-none text-[#FFF3E0] [text-shadow:0_0_12px_rgba(255,160,60,0.5)]">
              {renderSplitAppName()}
            </h1>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onPageChange(Page.WALLET)}
            className="flex items-center gap-2.5 bg-[#0a0a0a] border-[1.5px] border-[rgba(243,122,32,0.45)] pl-4 pr-1.5 py-1.5 rounded-full active:scale-[0.97] transition-all"
          >
            <span className="text-white font-extrabold text-xs sm:text-sm tabular-nums">
              ₹{totalBalance.toLocaleString()}
            </span>
            <div className="w-7 h-7 bg-[rgba(243,122,32,0.18)] rounded-full flex items-center justify-center">
              <Wallet size={15} className="text-[#F37A1F] stroke-[2.2]" />
            </div>
          </button>
        </div>
      </div>
    </header>
  );
}
